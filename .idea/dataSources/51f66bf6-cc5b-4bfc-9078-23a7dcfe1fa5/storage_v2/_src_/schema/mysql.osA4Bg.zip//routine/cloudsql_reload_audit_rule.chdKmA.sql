create
    definer = root@localhost procedure cloudsql_reload_audit_rule(IN mode int)
BEGIN SELECT plugin_status INTO @status FROM information_schema.plugins WHERE plugin_name = 'cloudsql_mysql_audit'; IF @status = 'ACTIVE' AND mode <> 0 THEN SET @mode = mode; PREPARE stmt FROM 'SET GLOBAL cloudsql_mysql_audit_rules_reload=?'; EXECUTE stmt USING @mode; END IF; END;

